import React, { useEffect, useRef } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import "swiper/css/autoplay";
import { Navigation, Pagination, Autoplay } from "swiper/modules";
import { gsap } from "gsap";
import { Translate } from "translate-easy";

import product1 from "../../images/HANDS OFF MY BODY 2.svg";
import product2 from "../../images/Group 14.svg";
import product3 from "../../images/Untitled-1 1.svg";
import product4 from "../../images/HANDS OFF MY BODY 2.svg";
import background from "../../images/Vector.svg";
import Loading from "../Loading";

const products = [
  {
    id: 1,
    image: product1,
    text: "Learning Notebooks",
    buttonText: "Shop Now",
  },
  {
    id: 2,
    image: product2,
    text: "Digital Planners",
    buttonText: "Explore",
  },
  {
    id: 3,
    image: product3,
    text: "Sketch Books",
    buttonText: "Buy",
  },
  {
    id: 4,
    image: product4,
    text: "Art Supplies",
    buttonText: "Get Yours",
  },
];

const Product = ({ productsData, isLoading }) => {
  const swiperRef = useRef(null);
  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        ".swiper-slide",
        { opacity: 0, scale: 0.7 },
        { opacity: 1, scale: 1, duration: 1, stagger: 0.3 }
      );
    }, swiperRef.current);

    return () => ctx.revert();
  }, []);
  if (isLoading) {
    return <Loading /> ;
  }
  return (
    <div className="relative dark:bg-[#1a191a]">
      <div className="absolute inset-0 z-0">
        <img
          src={background}
          alt="Background"
          className="w-full md:w-[45vw] absolute top-36 object-cover"
        />
      </div>
      <div className="relative z-10 p-4 md:p-8" ref={swiperRef}>
        <h2 className="text-2xl md:text-4xl font-bold my-5 tracking-[1rem] text-center text-[--text]">
          <Translate>Products</Translate>
        </h2>
        <Swiper
          spaceBetween={20}
          loop={true}
          pagination={{ clickable: true }}
          navigation={{
            prevEl: ".swiper-button-prev-custom",
            nextEl: ".swiper-button-next-custom",
          }}
          autoplay={{ delay: 5000, disableOnInteraction: false }}
          modules={[Navigation, Pagination, Autoplay]}
          breakpoints={{
            640: {
              slidesPerView: 1,
            },
            768: {
              slidesPerView: 2,
            },
            1024: {
              slidesPerView: 3,
            },
          }}
          className="mySwiper h-[70vh] w-[90vw] md:w-[70vw] mx-auto"
        >
          {products.map((product) => (
            <SwiperSlide key={product.id} className="relative z-50">
              <div className="relative mt-8 md:mt-16 w-full mx-auto bg-[--black] h-[40vh] md:h-[50vh] shadow-md shadow-gray-700 dark:shadow-white rounded-tl-full rounded-tr-full">
                <img
                  src={product.image}
                  alt="Product"
                  className="w-full h-[30vh] md:h-[40vh] -top-10 object-contain relative"
                />
                <div className="absolute bottom-0 left-0 right-0 text-center py-2 md:py-5 px-3 md:px-6 rounded-b-lg shadow-md">
                  <h2 className="text-sm md:text-lg font-medium text-[--text] my-4">
                    <Translate>{product.text}</Translate>
                  </h2>
                </div>
                <button className="absolute -bottom-4 md:-bottom-6 left-1/2 transform -translate-x-1/2 w-32 md:w-40 bg-pink-100 hover:bg-pink-400 font-bold py-2 md:py-3 rounded-full">
                  <Translate>{product.buttonText}</Translate>
                </button>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    </div>
  );
};

export default Product;
